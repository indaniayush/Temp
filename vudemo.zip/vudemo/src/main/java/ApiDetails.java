public class ApiDetails {

    private String appName;
    private String apiVersion;
    private int counter;

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    @Override
    public String toString() {
        return "ApiDetails{" +
                "appName='" + appName + '\'' +
                ", apiVersion='" + apiVersion + '\'' +
                ", counter='" + counter + '\'' +
                '}';
    }
}
