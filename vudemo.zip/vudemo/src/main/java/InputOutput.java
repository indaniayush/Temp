/* Save this in a file called Main.java to compile and test it */

/* 
   Example file showing how to write a program that reads
   input from `input.txt` in the current directory
   and writes output to `output.txt` in the current directory
*/

/* Do not add a package declaration */

import java.util.*;
import java.io.*;

/* DO NOT CHANGE ANYTHING ABOVE THIS LINE */
/* You may add any imports here, if you wish, but only from the
   standard library */

/* Do not add a namespace declaration */

public class InputOutput {
    public static void main (String[] args) {
        int numLines = 0;
        List<AppDetails> appDetails = new ArrayList<>();
        String splitter = ",";

        try {
            Scanner in = new Scanner(new BufferedReader(new FileReader("C:\\Users\\DELL\\IdeaProjects\\vudemo\\src\\main\\resources\\input.txt")));

            /* Here we can read in the input file */
            /* In this example, we're reading all the lines of file
               `input.txt` and then ignoring them. 
               You should modify this part of the
               program to read and process the input as desired */
            while(in.hasNextLine()) {
                String line = in.nextLine();
                AppDetails apps = new AppDetails();
                String[] values = line.split(splitter);

                if (!line.isEmpty())
                    apps.setAppName(values[0]);
                    apps.setApiName(values[1]);
                    apps.setApiVersion(values[2]);

                    appDetails.add(apps);

                    numLines++;
            }

            printAppDetails(appDetails);

            /* In this example, we're writing `num_lines` to
               the file `output.txt`.
               You should modify this part of the
               program to write the desired output */

            PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("C:\\Users\\DELL\\IdeaProjects\\vudemo\\src\\main\\resources\\output.txt")));
            output.println("" + numLines);
            output.close();
        } catch (IOException e) {
            System.out.println("IO error in input.txt or output.txt");
        }
    }


    private static void printAppDetails(List<AppDetails> appListToPrint) {

        System.out.println("Input:");

        for (AppDetails anAppListToPrint : appListToPrint) {
            System.out.println("APPDETAILS [appName= " + anAppListToPrint.getAppName()
                    + " , apiName=" + anAppListToPrint.getApiName()
                    + " , apiVersion=" + anAppListToPrint.getApiVersion() + "]");
        }

        System.out.println();

        finalResult(appListToPrint);
    }

    private static void finalResult(List<AppDetails> appListToPrint){

        System.out.println("Output computations:\n");

        Map<String, ApiDetails> finalMap = new HashMap<>();
        ApiDetails apiDetails = new ApiDetails();

        for (AppDetails anAppListToPrint : appListToPrint) {
            System.out.print(finalMap.containsKey(anAppListToPrint.getApiName())+"\t");

            if (finalMap.containsKey(anAppListToPrint.getApiName())) {
                if (Integer.parseInt(finalMap.get(anAppListToPrint.getApiName()).getApiVersion()) > Integer.parseInt(anAppListToPrint.getApiVersion())) {
                    apiDetails.setAppName(anAppListToPrint.getAppName());
                    apiDetails.setApiVersion(anAppListToPrint.getApiVersion());
                    apiDetails.setCounter(finalMap.get(anAppListToPrint.getApiName()).getCounter() + 1);

                    System.out.println("counter: " + apiDetails.getCounter());

                    finalMap.put(anAppListToPrint.getApiName(), apiDetails);
                }

            } else {

                apiDetails.setAppName(anAppListToPrint.getAppName());
                apiDetails.setApiVersion(anAppListToPrint.getApiVersion());
                apiDetails.setCounter(1);

                finalMap.put(anAppListToPrint.getApiName(), apiDetails);
            }
        }

        System.out.println("\n");

        finalMap.forEach((k,v)->System.out.println("Key: " + k + ", Value: " + v));

    }

}
