public class AppDetails {
    private String appName;
    private String apiName;
    private String apiVersion;

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        String[] part = apiVersion.split("(?<=\\D)(?=\\d)");
        apiVersion = part[1];
        this.apiVersion = apiVersion;
    }
}
